$(window).on("load", function() {
    $(".preloader img").delay(1000).fadeOut(250);
    $(".preloader").delay(1250).fadeOut(250);
});

$(document).ready(function() {
    $(".navigation a").mouseover(function() {
        $(this).css("background-color", "#1e419b");
        $(this).find("li").css("color", "#fff");
    });
    $(".navigation a").mouseout(function() {
        $(this).css("background-color", "#fff");
        $(this).find("li").css("color", "#1e419b");
    });
});