$(window).on("load", function() {
    $(".preloader img").delay(1000).fadeOut(250);
    $(".preloader").delay(1250).fadeOut(250);
});

$(document).ready(function() {
    $(".navigation a").mouseover(function() {
        $(this).css("background-color", "#1e419b");
        $(this).find("li").css("color", "#fff");
    });
    $(".navigation a").mouseout(function() {
        $(this).css("background-color", "#fff");
        $(this).find("li").css("color", "#1e419b");
    });
    $(".submit-btn").click(function() {
        validateForm();
    });
});

function validateForm() {
    var formInvalid = false;
    $('.input-text').each(function() {
        $(this).css("color", "#1e419b");
        $(this).css("border-color", "#1e419b");
        $(this).parent().children(".label").css("color", "#1e419b");
        if ($(this).val() === '') {
            formInvalid = true;
            $(this).css("color", "#ce2029");
            $(this).css("border-color", "#ce2029");
            $(this).parent().children(".label").css("color", "#ce2029");
        }
    });

    if (formInvalid) {
        alert('Please fill up all of the fields.')
    }
}